#include <iostream>
#include <cmath>

using namespace std;

// Functie pentru a converti un numar din baza sursa in baza 10
int conversieInDecimal(int numar, int bazaSursa) {
    int numarDecimal = 0;
    int putere = 0;
    while (numar > 0) {
        int cifra = numar % 10;
        if (cifra >= bazaSursa) {
            cout << "Numarul introdus nu este valid in baza specificata." << endl;
            exit(1);
        }
        numarDecimal += cifra * pow(bazaSursa, putere);
        numar /= 10;
        putere++;
    }
    return numarDecimal;
}

// Functie pentru a converti un numar din baza 10 in baza destinatie
int conversieDinDecimal(int numar, int bazaDestinatie) {
    int rezultat = 0;
    int putere = 0;
    while (numar > 0) {
        int rest = numar % bazaDestinatie;
        rezultat += rest * pow(10, putere);
        numar /= bazaDestinatie;
        putere++;
    }
    return rezultat;
}

int main() {
    int bazaSursa, bazaDestinatie, numar;

    cout << "Introduceti baza numarului de intrare (intre 2 si 26): ";
    cin >> bazaSursa;
    if (bazaSursa < 2 || bazaSursa > 26) {
        cout << "Baza introdusa nu este valida." << endl;
        return 1;
    }

    cout << "Introduceti numarul in baza " << bazaSursa << ": ";
    cin >> numar;

    cout << "Introduceti baza de iesire (intre 2 si 26): ";
    cin >> bazaDestinatie;
    if (bazaDestinatie < 2 || bazaDestinatie > 26) {
        cout << "Baza introdusa nu este valida." << endl;
        return 1;
    }

    int numarDecimal = conversieInDecimal(numar, bazaSursa);
    int rezultat = conversieDinDecimal(numarDecimal, bazaDestinatie);

    cout << "Rezultatul in baza " << bazaDestinatie << " este: " << rezultat << endl;

    return 0;
}
